package com.example.tp;

import java.util.ArrayList;

public class Microphone {

    public int[][] matriceUn; //Trois matrice pour les scénarios
    public int[][] matriceDeux;
    public int[][] matriceTrois;
    public ArrayList<int[][]> listMat; //ArrayList pour contenir les matrices et pouvoir les choisir ensuite
    public Signal monSignal;
    public int[][] matriceComparaison;
    public int choixMatrice;
    public int compteur;
    public Distance maDistance;
    public int[][] matriceBase;

    Microphone() {
        matriceUn = new int[8][7]; //Initialisation des différentes matrices et mise en place
        matriceDeux = new int[8][7];
        matriceTrois = new int[8][7];
        matriceComparaison = new int[8][7];
        matriceBase = new int[8][7];//Création des deux matrices qui seront comparées
        setMatriceUn();
        setMatriceDeux();
        setMatriceTrois();
        listMat = new ArrayList<int[][]>(); //Ajout des trois matrices "scénarisées" dans l'ArrayList
        listMat.add(matriceUn);
        listMat.add(matriceDeux);
        listMat.add(matriceTrois);
        monSignal = new Signal(); //Création du signal et de la distance
        maDistance = new Distance(matriceBase);
    }

    public void traitement() {
        if(monSignal.getEmis()){ //On vérifie si le micro reçoit un signal
        choixMatrice = monSignal.genererAleatoire(); //On choisit une matrice aléatoirement pour illustrer
        matriceComparaison = listMat.get(choixMatrice);
        maDistance.comparaison(matriceComparaison); //Comparaison de la matrice de comparaison avec la matrice de base
        compteur = maDistance.getCompteurComparaison();} //On récupère le nombre de comparaisons bonnes si on veut l'afficher
    }

    public void setMatriceUn() {
        for (int i = 0; i < matriceUn.length; i++) {
            for (int j = 0; j < matriceUn[i].length; j++) {
                matriceUn[i][j] = 0; //On initialise tout à 0
            }
        }
        /*On créer dans la matrice un "un" pour comparaison*/
        matriceUn[0][3] = 1;
        matriceUn[1][3] = 1;
        matriceUn[1][2] = 1;
        matriceUn[1][4] = 1;
        matriceUn[2][3] = 1;
        matriceUn[3][1] = 1;
        matriceUn[3][2] = 1;
        matriceUn[3][3] = 1;
        matriceUn[3][4] = 1;
        matriceUn[3][5] = 1;
        matriceUn[4][3] = 1;
        matriceUn[5][3] = 1;
        matriceUn[6][2] = 1;
        matriceUn[6][4] = 1;
        matriceUn[7][1] = 1;
        matriceUn[7][5] = 1;

    }

    public void setMatriceDeux() {
        for (int i = 0; i < matriceDeux.length; i++) {
            for (int j = 0; j < matriceDeux[i].length; j++) {
                matriceDeux[i][j] = 0; //On initialise tout à 0
            }
        }
        /*On créer dans la mtrice un "deux" pour comparaison*/
        matriceDeux[0][3] = 0;
        matriceDeux[1][3] = 0;
        matriceDeux[1][2] = 1;
        matriceDeux[1][4] = 1;
        matriceDeux[2][3] = 1;
        matriceDeux[3][1] = 0;
        matriceDeux[3][2] = 1;
        matriceDeux[3][3] = 1;
        matriceDeux[3][4] = 0;
        matriceDeux[3][5] = 0;
        matriceDeux[4][3] = 1;
        matriceDeux[5][3] = 1;
        matriceDeux[6][2] = 0;
        matriceDeux[6][4] = 1;
        matriceDeux[7][1] = 1;
        matriceDeux[7][5] = 1;

    }

    public void setMatriceTrois() {
        for (int i = 0; i < matriceTrois.length; i++) {
            for (int j = 0; j < matriceTrois[i].length; j++) {
                matriceTrois[i][j] = 0; //On initialise tout à 0
            }
        }
        /*On créer dans la mtrice un "trois" pour comparaison*/
        matriceTrois[0][3] = 1;
        matriceTrois[1][4] = 1;
        matriceTrois[1][3] = 1;
        matriceTrois[1][5] = 1;
        matriceTrois[2][3] = 1;
        matriceTrois[3][6] = 1;
        matriceTrois[3][2] = 1;
        matriceTrois[3][6] = 1;
        matriceTrois[3][4] = 1;
        matriceTrois[3][5] = 1;
        matriceTrois[4][6] = 1;
        matriceTrois[5][6] = 1;
        matriceTrois[6][3] = 1;
        matriceTrois[6][6] = 1;
        matriceTrois[7][1] = 1;
        matriceTrois[7][5] = 1;

    }
}

