package com.example.tp;

public class Distance {

    String textM;
    int compteurComparaison;

    public Distance(){};

    public Distance(int[][] matriceBase) {
        for (int i = 0; i < matriceBase.length; i++) {
            for (int j = 0; j < matriceBase[i].length; j++) {
                matriceBase[i][j] = 0; //On initialise tout à 0
            }
        }
        /*On créer dans la matrice un "homme" pour comparaison*/
        matriceBase[0][3] = 1;
        matriceBase[1][3] = 1;
        matriceBase[1][2] = 1;
        matriceBase[1][4] = 1;
        matriceBase[2][3] = 1;
        matriceBase[3][1] = 1;
        matriceBase[3][2] = 1;
        matriceBase[3][3] = 1;
        matriceBase[3][4] = 1;
        matriceBase[3][5] = 1;
        matriceBase[4][3] = 1;
        matriceBase[5][3] = 1;
        matriceBase[6][2] = 1;
        matriceBase[6][4] = 1;
        matriceBase[7][1] = 1;
        matriceBase[7][5] = 1;
    }



    public void afficherMatrice(int[][] matrice) {

        textM = "";

        for (int i = 0; i < matrice.length; i++) {
            for (int j = 0; j < matrice[i].length; j++) {
                textM += Integer.toString(matrice[i][j]); //On met TOUTE la matrice dans une chaîne de caractère
            }
        }

    }

    public int comparaison(int[][] matrice) { //On compare les cases de l'homme avec ceux de la matrice pour voir s'il y a un certain niveau de correspondance
        compteurComparaison=0;
        if (matrice[0][3] == 1) {
            compteurComparaison++;}
        if(matrice[1][3] == 1){
            compteurComparaison++;}
        if(matrice[1][2] == 1 ){
            compteurComparaison++;}
        if(matrice[1][4] == 1 ){
            compteurComparaison++;}
        if(matrice[2][3] == 1 ){
            compteurComparaison++;}
        if(matrice[3][1] == 1 ){
            compteurComparaison++;}
        if(matrice[3][2] == 1 ){
            compteurComparaison++;}
        if(matrice[3][3] == 1 ){
            compteurComparaison++;}
        if(matrice[3][4] == 1 ){
            compteurComparaison++;}
        if(matrice[3][5] == 1 ){
            compteurComparaison++;}
        if(matrice[4][3] == 1 ){
            compteurComparaison++;}
        if(matrice[5][3] == 1 ){
            compteurComparaison++;}
        if(matrice[6][2] == 1 ){
            compteurComparaison++;}
        if(matrice[6][4] == 1 ){
            compteurComparaison++;}
        if(matrice[7][1] == 1 ){
            compteurComparaison++;}
        if(matrice[7][5] == 1) {
            compteurComparaison++;
        }
        return compteurComparaison;
    }

    public int getCompteurComparaison() { //Retourne le nombre de correspondance
        return compteurComparaison;
    }
}


