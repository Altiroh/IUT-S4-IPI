package com.example.tp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Console;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Random;

public class Simulation extends AppCompatActivity {

    /*Déclaration des différentes variables*/

    public TextView matriceT;
    public int i;
    public int[][] matriceComparaison;
    public ArrayList<int[][]> listMat;
    public String textM = "";
    public int nombreA = 0;
    public int choixMatrice;
    public int compteurComparaison = 0;


    Signal signal;
    Microphone micro;
    HautParleur hp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simulation);

        matriceT = findViewById(R.id.tv_matrice);

        matriceComparaison = new int[8][7];


        signal = new Signal();
        micro = new Microphone();
        hp = new HautParleur();


        Toast.makeText(Simulation.this, "Toutes les matrices existent !", Toast.LENGTH_SHORT).show();

    }

    public void onClick(View v) { //gestion des clicks
    switch(v.getId()){
        case R.id.b_arreter: //Si bouton arrêter
            micro.traitement(); //Lancement du traitement du signal reçu
            hp.setActif(false); //On arrête d'émettre
            break;
        case R.id.b_simulation:
            hp.setActif(true); //On recommence à émettre
    }


    }

}


