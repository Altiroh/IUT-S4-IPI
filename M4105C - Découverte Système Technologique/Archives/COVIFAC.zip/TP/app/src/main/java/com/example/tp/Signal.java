package com.example.tp;

import java.util.Random;

public class Signal {

    public Random randomGenerator;
    public int nombreA=0;
    public HautParleur hp;
    public boolean estEmis;

    public Signal(){
        hp = new HautParleur();
    }



    public int genererAleatoire() { //Generation aleatoire du numéro de la matrice

        if (hp.getActif()) { //On vérifie déjà que le haut parleur à émis pour "créer" le signal
            estEmis=true;}
            else{
                estEmis=false;}

                if(estEmis){
            if (randomGenerator == null) { //Si le generateur de nombre n'existe pas on le crée
                randomGenerator = new Random();
            }
            nombreA = randomGenerator.nextInt(2); //S'il y a un signal, on génère un nombre entre 0 et 2
        }
        return nombreA;
    }

    public boolean getEmis(){ //On retourne l'état du signal
        return estEmis;
    }

}
