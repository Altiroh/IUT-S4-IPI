package com.example.tp;

public class HautParleur {

    public boolean estActif=true;

    public boolean getActif(){
        return this.estActif; //retourne l'état du haut-parleur
    }

    public void setActif(boolean actif){
        this.estActif=actif; //Activation ou désactivation du haut parleur
    }

}
