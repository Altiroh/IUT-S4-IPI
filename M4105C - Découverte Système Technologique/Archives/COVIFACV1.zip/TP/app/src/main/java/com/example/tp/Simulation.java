package com.example.tp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Console;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Random;

public class Simulation extends AppCompatActivity {

    /*Déclaration des différentes variables*/

    public TextView matriceT;
    public int i;
    public int[][] matriceBase;
    public int[][] matriceUn;
    public int[][] matriceDeux;
    public int[][] matriceTrois;
    public int[][] matriceComparaison;
    public ArrayList<int[][]> listMat;
    public String textM = "";
    public int nombreA = 0;
    public int choixMatrice;
    public Random randomGenerator;
    public int compteurComparaison = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_simulation);

        matriceT = findViewById(R.id.tv_matrice);

        matriceBase = new int[8][7];
        matriceUn = new int[8][7];
        matriceDeux = new int[8][7];
        matriceTrois = new int[8][7];//Création des deux matrices qui seront comparées
        matriceComparaison = new int[8][7];
        listMat = new ArrayList<int[][]>();


        setMatriceUn();
        setMatriceDeux();
        setMatriceTrois();

        listMat.add(matriceUn);
        listMat.add(matriceDeux);
        listMat.add(matriceTrois);

        setMatriceBase(matriceBase); //Appel de la méthode pour initialiser la matrice de base

        Toast.makeText(Simulation.this,"Toutes les matrices existent !",Toast.LENGTH_SHORT).show();

    }

    public void onClick(View v) { //Lancement de la génération de la seconde matrice puis initialisation

        choixMatrice=genererAleatoire();
        matriceComparaison = listMat.get(choixMatrice);

        afficherMatrice(matriceComparaison); //Appel de la méthode pour afficher la matrice [pour le test]

        comparaison(matriceComparaison);

    }


    public void setMatriceBase(int[][] matriceBase) {
        for (int i = 0; i < matriceBase.length; i++) {
            for (int j = 0; j < matriceBase[i].length; j++) {
                matriceBase[i][j] = 0; //On initialise tout à 0
            }
        }
        /*On créer dans la matrice un "homme" pour comparaison*/
        matriceBase[0][3] = 1;
        matriceBase[1][3] = 1;
        matriceBase[1][2] = 1;
        matriceBase[1][4] = 1;
        matriceBase[2][3] = 1;
        matriceBase[3][1] = 1;
        matriceBase[3][2] = 1;
        matriceBase[3][3] = 1;
        matriceBase[3][4] = 1;
        matriceBase[3][5] = 1;
        matriceBase[4][3] = 1;
        matriceBase[5][3] = 1;
        matriceBase[6][2] = 1;
        matriceBase[6][4] = 1;
        matriceBase[7][1] = 1;
        matriceBase[7][5] = 1;

    }

    public void setMatriceUn() {
        for (int i = 0; i < matriceUn.length; i++) {
            for (int j = 0; j < matriceUn[i].length; j++) {
                matriceUn[i][j] = 0; //On initialise tout à 0
            }
        }
        /*On créer dans la matrice un "homme" pour comparaison*/
        matriceUn[0][3] = 1;
        matriceUn[1][3] = 1;
        matriceUn[1][2] = 1;
        matriceUn[1][4] = 1;
        matriceUn[2][3] = 1;
        matriceUn[3][1] = 1;
        matriceUn[3][2] = 1;
        matriceUn[3][3] = 1;
        matriceUn[3][4] = 1;
        matriceUn[3][5] = 1;
        matriceUn[4][3] = 1;
        matriceUn[5][3] = 1;
        matriceUn[6][2] = 1;
        matriceUn[6][4] = 1;
        matriceUn[7][1] = 1;
        matriceUn[7][5] = 1;

    }

    public void setMatriceDeux() {
        for (int i = 0; i < matriceDeux.length; i++) {
            for (int j = 0; j < matriceDeux[i].length; j++) {
                matriceDeux[i][j] = 0; //On initialise tout à 0
            }
        }
        /*On créer dans la mtrice un "homme" pour comparaison*/
        matriceDeux[0][3] = 0;
        matriceDeux[1][3] = 0;
        matriceDeux[1][2] = 1;
        matriceDeux[1][4] = 1;
        matriceDeux[2][3] = 1;
        matriceDeux[3][1] = 0;
        matriceDeux[3][2] = 1;
        matriceDeux[3][3] = 1;
        matriceDeux[3][4] = 0;
        matriceDeux[3][5] = 0;
        matriceDeux[4][3] = 1;
        matriceDeux[5][3] = 1;
        matriceDeux[6][2] = 0;
        matriceDeux[6][4] = 1;
        matriceDeux[7][1] = 1;
        matriceDeux[7][5] = 1;

    }

    public void setMatriceTrois() {
        for (int i = 0; i < matriceTrois.length; i++) {
            for (int j = 0; j < matriceTrois[i].length; j++) {
                matriceTrois[i][j] = 0; //On initialise tout à 0
            }
        }
        /*On créer dans la mtrice un "homme" pour comparaison*/
        matriceTrois[0][3] = 1;
        matriceTrois[1][4] = 1;
        matriceTrois[1][3] = 1;
        matriceTrois[1][5] = 1;
        matriceTrois[2][3] = 1;
        matriceTrois[3][6] = 1;
        matriceTrois[3][2] = 1;
        matriceTrois[3][6] = 1;
        matriceTrois[3][4] = 1;
        matriceTrois[3][5] = 1;
        matriceTrois[4][6] = 1;
        matriceTrois[5][6] = 1;
        matriceTrois[6][3] = 1;
        matriceTrois[6][6] = 1;
        matriceTrois[7][1] = 1;
        matriceTrois[7][5] = 1;

    }

    public void afficherMatrice(int[][] matrice) {

        textM = "";

        for (int i = 0; i < matrice.length; i++) {
            for (int j = 0; j < matrice[i].length; j++) {
                textM += Integer.toString(matrice[i][j]); //On met TOUTE la matrice dans une chaîne de caractère
            }
        }

        //matriceT.setText(textM); //On met la chaîne dans le TextView
    }

    public int genererAleatoire() {
        if (randomGenerator == null) {
            randomGenerator = new Random();
        }
        nombreA = randomGenerator.nextInt(2);
        return nombreA;
    }

    public void comparaison(int[][] matrice) {
        compteurComparaison=0;
        if (matrice[0][3] == 1) {
            compteurComparaison++;}
        if(matrice[1][3] == 1){
            compteurComparaison++;}
        if(matrice[1][2] == 1 ){
            compteurComparaison++;}
            if(matrice[1][4] == 1 ){
                compteurComparaison++;}
            if(matrice[2][3] == 1 ){
                compteurComparaison++;}
            if(matrice[3][1] == 1 ){
                compteurComparaison++;}
            if(matrice[3][2] == 1 ){
                compteurComparaison++;}
            if(matrice[3][3] == 1 ){
                compteurComparaison++;}
            if(matrice[3][4] == 1 ){
                compteurComparaison++;}
            if(matrice[3][5] == 1 ){
                compteurComparaison++;}
            if(matrice[4][3] == 1 ){
                compteurComparaison++;}
            if(matrice[5][3] == 1 ){
                compteurComparaison++;}
            if(matrice[6][2] == 1 ){
                compteurComparaison++;}
            if(matrice[6][4] == 1 ){
                compteurComparaison++;}
            if(matrice[7][1] == 1 ){
                compteurComparaison++;}
            if(matrice[7][5] == 1) {
                    compteurComparaison++;
                }

        if(compteurComparaison>=12){
            Toast.makeText(Simulation.this,"C'est un humain !",Toast.LENGTH_SHORT).show();
            matriceT.setText(Integer.toString(compteurComparaison));
        }
        else{
            Toast.makeText(Simulation.this,"C'est un objet !",Toast.LENGTH_SHORT).show();
            matriceT.setText(Integer.toString(compteurComparaison));
        }

    }

    private class HautParleur{

    }

    private class Microphone{

    }

    private class Signal{

    }

    private class Distance{
        public int[][] matriceBase;
    }

    private class Utilisateur{

    }

}
